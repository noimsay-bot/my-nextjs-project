import { HomeNewsDataset } from "@/components/home/home-news.types";

export const homeNewsMockData: HomeNewsDataset = {
  sourceKind: "fallback_mock",
  temporarySections: [
    {
      id: "local_election",
      label: "지방선거",
      items: [],
    },
  ],
  tickerItems: [
    {
      id: "politics-budget",
      category: "politics",
      text: "여야가 추경 협상 재개 시점을 두고 신경전을 이어가며 오전 회동 결과가 오늘 정치권 핵심 변수로 거론됩니다.",
      priority: "high",
    },
    {
      id: "society-safety",
      category: "society",
      text: "도심 혼잡과 안전 점검 이슈가 겹치며 퇴근 시간대 통제 구간과 현장 동선을 미리 확인해야 한다는 분위기입니다.",
      priority: "high",
    },
    {
      id: "economy-market",
      category: "economy",
      text: "환율과 유가가 동시에 흔들리면서 체감 물가와 기업 비용 부담을 함께 점검해야 한다는 분석이 이어집니다.",
      priority: "medium",
    },
    {
      id: "world-fed",
      category: "world",
      text: "미국 금리 발언과 중동 정세가 맞물리며 글로벌 시장이 방향성을 탐색하는 흐름이라 밤사이 변수 관리가 중요해졌습니다.",
      priority: "medium",
    },
  ],
  cardsByCategory: {
    politics: [
      {
        id: "politics-1",
        category: "politics",
        title: "여야 추경 협상 재가동 여부에 시선 집중",
        summary: [
          "원내지도부가 오늘 오전 비공개 접촉을 이어가며 추경 처리 일정의 접점을 찾고 있습니다.",
          "쟁점은 민생 예산 우선 배치와 지역 사업 반영 범위로 압축되는 분위기입니다.",
          "합의가 늦어질수록 책임 공방도 더 커질 가능성이 있습니다.",
        ],
        whyItMatters: "추경 일정은 민생 대응 속도와 정치권 주도권 프레임에 동시에 영향을 줍니다.",
        checkPoints: ["회동 직후 브리핑에서 실무협상 연장인지, 구체적 합의 문구가 나오는지 확인이 필요합니다."],
        priority: "high",
      },
      {
        id: "politics-2",
        category: "politics",
        title: "후속 인선 발표 가능성 속 검증 공방 예고",
        summary: [
          "대통령실 후속 인선이 임박했다는 관측이 나오며 정치권 긴장감이 높아지고 있습니다.",
          "야권은 인사 검증 기준을 먼저 공개하라고 압박하는 상황입니다.",
          "발표 이후에는 청문회 일정과 증인 채택 공방이 빠르게 이어질 수 있습니다.",
        ],
        whyItMatters: "인사 이슈는 국정 운영 동력과 직결돼 작은 논란도 큰 정치 프레임으로 번질 수 있습니다.",
        checkPoints: ["대통령실 일정 변화와 핵심 인사 발언 수위를 함께 보는 게 좋습니다."],
        priority: "medium",
      },
      {
        id: "politics-3",
        category: "politics",
        title: "정당 조직 재정비 논의가 내부 갈등 변수로 부상",
        summary: [
          "주요 정당이 지도체제 개편과 인재 영입 방향을 놓고 내부 토론을 이어가고 있습니다.",
          "표면상 쇄신 논의지만 실제로는 계파별 주도권 경쟁 성격이 강하다는 해석이 나옵니다.",
        ],
        whyItMatters: "조직 재편 방향은 향후 메시지 전략과 공천 구조까지 이어질 수 있습니다.",
        checkPoints: ["회의 뒤 핵심 인사 발언에서 통합, 쇄신, 책임론 중 어떤 키워드가 부각되는지 확인해야 합니다."],
      },
    ],
    society: [
      {
        id: "society-1",
        category: "society",
        title: "도심 집회와 출퇴근 동선 겹치며 안전 관리 비상",
        summary: [
          "대규모 집회 신고가 겹치면서 경찰과 지자체가 우회 동선 점검에 나선 상태입니다.",
          "평일 퇴근 시간대와 이동 경로가 겹치는 구간이 많아 시민 불편이 커질 수 있습니다.",
          "현장 안전요원 배치와 실시간 고지가 핵심 대응 포인트로 꼽힙니다.",
        ],
        whyItMatters: "안전 이슈는 혼잡을 넘어 현장 사고 가능성과 직접 연결돼 대응 실패가 크게 부각될 수 있습니다.",
        checkPoints: ["교통 통제 시각, 참가 인원 추정치, 지하철 무정차 여부를 실시간으로 확인해야 합니다."],
        priority: "high",
      },
      {
        id: "society-2",
        category: "society",
        title: "의료 현장 공백 대응책 추가 발표 가능성 주목",
        summary: [
          "정부와 의료계가 공개 충돌을 이어가는 가운데 보완 대책이 추가로 나올 가능성이 거론됩니다.",
          "일선 병원은 응급과 중증 진료 중심으로 운영 조정을 이어가고 있습니다.",
          "환자 불편이 길어지며 정책 설명력 부족을 지적하는 목소리도 커지고 있습니다.",
        ],
        whyItMatters: "현장 공백이 장기화되면 정책 이슈가 생활 이슈로 전환되며 체감도가 급격히 커집니다.",
        checkPoints: ["정부 브리핑에서 신규 인력 투입, 협상 재개, 수가 보완 중 무엇이 나오느냐가 관건입니다."],
      },
    ],
    economy: [
      {
        id: "economy-1",
        category: "economy",
        title: "환율과 유가 동반 상승에 물가 부담 재부각",
        summary: [
          "원달러 환율이 높은 수준을 유지하는 가운데 국제유가도 오름세를 이어가고 있습니다.",
          "수입 물가 부담이 커지면 생활물가와 기업 원가 압박이 동시에 확대될 수 있습니다.",
          "운송과 식품 업종 중심으로 가격 전가 우려가 다시 커지는 분위기입니다.",
        ],
        whyItMatters: "환율과 유가는 체감 물가에 직접 연결돼 경제 뉴스의 파급력이 매우 큽니다.",
        checkPoints: ["장중 환율 흐름과 정부의 물가 대응 발언 유무를 함께 점검해야 합니다."],
        priority: "high",
      },
      {
        id: "economy-2",
        category: "economy",
        title: "금리 인하 기대와 대출 관리 사이 줄다리기",
        summary: [
          "시장은 완화 기대를 유지하지만 금융당국은 가계대출 증가 속도에 경계감을 보이고 있습니다.",
          "규제 메시지가 다시 강화되면 부동산과 소비 심리에 동시에 영향을 줄 수 있습니다.",
        ],
        whyItMatters: "금리 기대와 규제 메시지가 엇갈리면 시장 해석이 흔들리며 자산가격 변동성이 커질 수 있습니다.",
        checkPoints: ["당국 발언에서 안정, 관리, 실수요 보호 중 어떤 표현이 강조되는지 볼 필요가 있습니다."],
      },
    ],
    world: [
      {
        id: "world-1",
        category: "world",
        title: "미국 통화정책 발언 앞두고 시장 경계감 확대",
        summary: [
          "연준 인사들의 공개 발언이 예정돼 있어 밤사이 금리 경로 해석이 다시 흔들릴 가능성이 있습니다.",
          "시장 참여자들은 지표보다도 발언 톤 변화에 더 민감하게 반응하는 흐름입니다.",
          "주식과 채권, 달러가 동시 변동하는 장세가 이어질 수 있다는 전망도 나옵니다.",
        ],
        whyItMatters: "미국 금리 신호는 국내 환율과 외국인 수급까지 연결돼 다음 날 기사 흐름에 바로 영향을 줍니다.",
        checkPoints: ["발언 직후 채권 금리와 달러 지수가 어떤 방향으로 움직이는지 확인해야 합니다."],
        priority: "high",
      },
      {
        id: "world-2",
        category: "world",
        title: "중동 긴장 고조에 에너지 시장 불안 재점화",
        summary: [
          "현지 충돌 가능성이 다시 커지면서 국제 원자재 시장이 민감하게 반응하고 있습니다.",
          "실제 공급 차질이 없더라도 가격은 선반영되는 흐름이 나타나고 있습니다.",
        ],
        whyItMatters: "중동 변수는 에너지 가격과 물류 비용, 글로벌 위험자산 심리까지 광범위하게 흔듭니다.",
        checkPoints: ["국제유가 선물과 주요국 외교 발언, 해상 운임 반응을 함께 봐야 합니다."],
        priority: "medium",
      },
    ],
  },
};
